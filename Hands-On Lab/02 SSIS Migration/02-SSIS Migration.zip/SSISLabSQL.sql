
USE [2008DW]
Go

---This is a shared environment
---update 'xxxxx' to your UserName so you dont delete other users data

--- 1. Get name of Managed Instance

SELECT @@SERVERNAME

--- 2. List of all UserNames
SELECT distinct(SSISUserName) FROM [2008DW].[dbo].[Country]

--- 3. Select your data from Data warehouse

SELECT * FROM [2008DW].[dbo].[Country]
WHERE SSISUserName = 'xxxxx'

SELECT * FROM [2008DW].[dbo].[Users]
WHERE SSISUserName = 'xxxxx'

SELECT * FROM [2008DW].[dbo].[UserTransactions]
WHERE SSISUserName = 'xxxxx'

-- 4. Delete your user data from Data Warehouse

--DELETE FROM [2008DW].[dbo].[Country]
--WHERE SSISUserName = 'xxxxx'

--DELETE FROM [2008DW].[dbo].[Users]
--WHERE SSISUserName = 'xxxxx'

--DELETE FROM [2008DW].[dbo].[UserTransactions]
--WHERE SSISUserName = 'xxxxx'